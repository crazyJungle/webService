﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebServiceCaller
{
    public partial class CallText : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            localhost.WebService1 ws = new localhost.WebService1();
            localhost.MySopeHeader header = new localhost.MySopeHeader();
            header.checkpwd = "123456";
            ws.MySopeHeaderValue = header;
            Response.Write(ws.HelloWorld());
        }
    }
}